package ch06.sec06.exam01;

public class Car {
    // 필드 선언
    // 같은 패키지 내에서만 접근 가능 (default 접근 제한자 생략)
    String model; // 초기값 null
    boolean start; // 초기값 false
    int speed; // 초기값 0
}
